function Error() {
    return (
        <h1>Page not Found</h1>
    );
}

export default Error;